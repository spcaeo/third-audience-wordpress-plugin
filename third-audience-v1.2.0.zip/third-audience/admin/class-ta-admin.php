<?php
/**
 * Admin - Settings page and admin functionality.
 *
 * Handles the admin interface, settings registration, AJAX handlers,
 * and SMTP/notification configuration.
 *
 * @package ThirdAudience
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class TA_Admin
 *
 * Admin functionality for Third Audience plugin.
 *
 * @since 1.0.0
 */
class TA_Admin {

	/**
	 * Security instance.
	 *
	 * @var TA_Security
	 */
	private $security;

	/**
	 * Logger instance.
	 *
	 * @var TA_Logger
	 */
	private $logger;

	/**
	 * Notifications instance.
	 *
	 * @var TA_Notifications
	 */
	private $notifications;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 */
	public function __construct() {
		$this->security      = TA_Security::get_instance();
		$this->logger        = TA_Logger::get_instance();
		$this->notifications = TA_Notifications::get_instance();
	}

	/**
	 * Initialize admin functionality.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		// Admin post handlers.
		add_action( 'admin_post_ta_clear_cache', array( $this, 'handle_clear_cache' ) );
		add_action( 'admin_post_ta_test_connection', array( $this, 'handle_test_connection' ) );
		add_action( 'admin_post_ta_test_smtp', array( $this, 'handle_test_smtp' ) );
		add_action( 'admin_post_ta_clear_errors', array( $this, 'handle_clear_errors' ) );
		add_action( 'admin_post_ta_save_smtp_settings', array( $this, 'handle_save_smtp_settings' ) );
		add_action( 'admin_post_ta_save_notification_settings', array( $this, 'handle_save_notification_settings' ) );

		// AJAX handlers.
		add_action( 'wp_ajax_ta_test_connection', array( $this, 'ajax_test_connection' ) );
		add_action( 'wp_ajax_ta_test_smtp', array( $this, 'ajax_test_smtp' ) );
		add_action( 'wp_ajax_ta_clear_cache', array( $this, 'ajax_clear_cache' ) );
		add_action( 'wp_ajax_ta_get_recent_errors', array( $this, 'ajax_get_recent_errors' ) );
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @since 1.1.0
	 * @param string $hook The current admin page hook.
	 * @return void
	 */
	public function enqueue_scripts( $hook ) {
		if ( 'settings_page_third-audience' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'ta-admin',
			TA_PLUGIN_URL . 'admin/css/admin.css',
			array(),
			TA_VERSION
		);

		wp_enqueue_script(
			'ta-admin',
			TA_PLUGIN_URL . 'admin/js/admin.js',
			array( 'jquery' ),
			TA_VERSION,
			true
		);

		wp_localize_script( 'ta-admin', 'taAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => $this->security->create_nonce( 'admin_ajax' ),
			'i18n'    => array(
				'testing'        => __( 'Testing...', 'third-audience' ),
				'clearing'       => __( 'Clearing...', 'third-audience' ),
				'success'        => __( 'Success!', 'third-audience' ),
				'error'          => __( 'Error', 'third-audience' ),
				'confirmClear'   => __( 'Are you sure you want to clear all cached items?', 'third-audience' ),
				'confirmClearErrors' => __( 'Are you sure you want to clear all error logs?', 'third-audience' ),
			),
		) );
	}

	/**
	 * Add settings page to admin menu.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function add_settings_page() {
		add_options_page(
			__( 'Third Audience Settings', 'third-audience' ),
			__( 'Third Audience', 'third-audience' ),
			'manage_options',
			'third-audience',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_settings() {
		// Service settings.
		register_setting( 'ta_settings', 'ta_router_url', array(
			'type'              => 'string',
			'sanitize_callback' => array( $this->security, 'sanitize_url' ),
			'default'           => '',
		) );

		register_setting( 'ta_settings', 'ta_worker_url', array(
			'type'              => 'string',
			'sanitize_callback' => array( $this->security, 'sanitize_url' ),
			'default'           => 'https://ta-worker.rp-2ae.workers.dev',
		) );

		register_setting( 'ta_settings', 'ta_api_key', array(
			'type'              => 'string',
			'sanitize_callback' => array( $this, 'sanitize_api_key' ),
		) );

		// Cache settings.
		register_setting( 'ta_settings', 'ta_cache_ttl', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 86400,
		) );

		// Feature settings.
		register_setting( 'ta_settings', 'ta_enabled_post_types', array(
			'type'              => 'array',
			'sanitize_callback' => array( $this->security, 'sanitize_post_types' ),
			'default'           => array( 'post', 'page' ),
		) );

		register_setting( 'ta_settings', 'ta_enable_content_negotiation', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => true,
		) );

		register_setting( 'ta_settings', 'ta_enable_discovery_tags', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => true,
		) );
	}

	/**
	 * Sanitize API key (encrypt and store).
	 *
	 * @since 1.0.0
	 * @param string $value The API key.
	 * @return string Empty string (we store encrypted separately).
	 */
	public function sanitize_api_key( $value ) {
		if ( ! empty( $value ) ) {
			$value = $this->security->sanitize_text( $value );
			$this->security->store_encrypted_option( 'ta_api_key', $value );
			$this->logger->info( 'API key updated.' );
		}
		return ''; // Don't store unencrypted.
	}

	/**
	 * Render settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_settings_page() {
		$this->security->verify_admin_capability();

		// Show admin notices.
		settings_errors( 'ta_messages' );

		// Get cache stats.
		$cache_manager = new TA_Cache_Manager();
		$cache_stats   = $cache_manager->get_stats();

		// Get error stats.
		$error_stats   = $this->logger->get_stats();
		$recent_errors = $this->logger->get_recent_errors( 10 );

		// Get notification settings.
		$smtp_settings         = $this->notifications->get_smtp_settings();
		$notification_settings = $this->notifications->get_notification_settings();

		// Get current tab.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current_tab = isset( $_GET['tab'] ) ? $this->security->sanitize_text( $_GET['tab'] ) : 'general';

		include TA_PLUGIN_DIR . 'admin/views/settings-page.php';
	}

	/**
	 * Handle clear cache action.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function handle_clear_cache() {
		$this->security->verify_admin_capability();
		$this->security->verify_nonce_or_die( 'clear_cache' );

		$cache_manager = new TA_Cache_Manager();
		$cleared       = $cache_manager->clear_all();

		$this->logger->info( 'Cache cleared.', array( 'items' => $cleared ) );

		add_settings_error(
			'ta_messages',
			'ta_cache_cleared',
			/* translators: %d: Number of cached items cleared */
			sprintf( __( 'Cleared %d cached items.', 'third-audience' ), $cleared ),
			'success'
		);

		set_transient( 'settings_errors', get_settings_errors(), 30 );

		wp_safe_redirect( add_query_arg(
			array(
				'page'             => 'third-audience',
				'settings-updated' => 'true',
			),
			admin_url( 'options-general.php' )
		) );
		exit;
	}

	/**
	 * Handle test connection action.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function handle_test_connection() {
		$this->security->verify_admin_capability();
		$this->security->verify_nonce_or_die( 'test_connection' );

		$api_client = new TA_API_Client();
		$worker_url = $api_client->get_worker_url();

		// Validate URL.
		$validated_url = $this->security->validate_url_for_worker( $worker_url );
		if ( is_wp_error( $validated_url ) ) {
			add_settings_error(
				'ta_messages',
				'ta_test_failed',
				__( 'Invalid worker URL: ', 'third-audience' ) . $validated_url->get_error_message(),
				'error'
			);
			$this->redirect_to_settings();
			return;
		}

		// Test worker health.
		$response = wp_remote_get( $worker_url . '/health', array( 'timeout' => 10 ) );

		if ( is_wp_error( $response ) ) {
			$this->logger->error( 'Worker connection test failed.', array(
				'url'   => $worker_url,
				'error' => $response->get_error_message(),
			) );

			// Trigger notification.
			do_action( 'ta_worker_connection_failed', $worker_url, $response );

			add_settings_error(
				'ta_messages',
				'ta_test_failed',
				__( 'Connection failed: ', 'third-audience' ) . $response->get_error_message(),
				'error'
			);
		} else {
			$status_code = wp_remote_retrieve_response_code( $response );
			if ( 200 === $status_code ) {
				$this->logger->info( 'Worker connection test successful.', array( 'url' => $worker_url ) );
				add_settings_error(
					'ta_messages',
					'ta_test_success',
					__( 'Connection successful! Worker is healthy.', 'third-audience' ),
					'success'
				);
			} else {
				$this->logger->warning( 'Worker returned unexpected status.', array(
					'url'    => $worker_url,
					'status' => $status_code,
				) );
				add_settings_error(
					'ta_messages',
					'ta_test_failed',
					/* translators: %d: HTTP status code */
					sprintf( __( 'Worker returned status %d', 'third-audience' ), $status_code ),
					'error'
				);
			}
		}

		$this->redirect_to_settings();
	}

	/**
	 * Handle test SMTP action.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_test_smtp() {
		$this->security->verify_admin_capability();
		$this->security->verify_nonce_or_die( 'test_smtp' );

		$result = $this->notifications->test_smtp();

		if ( is_wp_error( $result ) ) {
			$this->logger->error( 'SMTP test failed.', array( 'error' => $result->get_error_message() ) );
			add_settings_error(
				'ta_messages',
				'ta_smtp_test_failed',
				__( 'SMTP test failed: ', 'third-audience' ) . $result->get_error_message(),
				'error'
			);
		} else {
			$this->logger->info( 'SMTP test successful.' );
			add_settings_error(
				'ta_messages',
				'ta_smtp_test_success',
				__( 'SMTP test email sent successfully!', 'third-audience' ),
				'success'
			);
		}

		$this->redirect_to_settings( 'notifications' );
	}

	/**
	 * Handle clear errors action.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_clear_errors() {
		$this->security->verify_admin_capability();
		$this->security->verify_nonce_or_die( 'clear_errors' );

		$this->logger->clear_errors();
		$this->logger->reset_stats();
		$this->logger->info( 'Error logs cleared by admin.' );

		add_settings_error(
			'ta_messages',
			'ta_errors_cleared',
			__( 'Error logs cleared.', 'third-audience' ),
			'success'
		);

		$this->redirect_to_settings( 'logs' );
	}

	/**
	 * Handle save SMTP settings action.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_save_smtp_settings() {
		$this->security->verify_admin_capability();
		$this->security->verify_nonce_or_die( 'save_smtp_settings' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$settings = isset( $_POST['ta_smtp'] ) && is_array( $_POST['ta_smtp'] ) ? $_POST['ta_smtp'] : array();

		// Sanitize settings.
		$sanitized = array(
			'enabled'    => isset( $settings['enabled'] ),
			'host'       => $this->security->sanitize_text( $settings['host'] ?? '' ),
			'port'       => absint( $settings['port'] ?? 587 ),
			'encryption' => in_array( $settings['encryption'] ?? 'tls', array( '', 'ssl', 'tls' ), true )
				? $settings['encryption']
				: 'tls',
			'username'   => $this->security->sanitize_text( $settings['username'] ?? '' ),
			'password'   => $settings['password'] ?? '', // Will be encrypted in save_smtp_settings.
			'from_email' => $this->security->sanitize_email( $settings['from_email'] ?? '' ),
			'from_name'  => $this->security->sanitize_text( $settings['from_name'] ?? '' ),
		);

		// Only update password if a new one was provided.
		if ( empty( $sanitized['password'] ) ) {
			$existing              = $this->notifications->get_smtp_settings();
			$sanitized['password'] = $existing['password'] ?? '';
		}

		$this->notifications->save_smtp_settings( $sanitized );
		$this->logger->info( 'SMTP settings updated.' );

		add_settings_error(
			'ta_messages',
			'ta_smtp_saved',
			__( 'SMTP settings saved.', 'third-audience' ),
			'success'
		);

		$this->redirect_to_settings( 'notifications' );
	}

	/**
	 * Handle save notification settings action.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_save_notification_settings() {
		$this->security->verify_admin_capability();
		$this->security->verify_nonce_or_die( 'save_notification_settings' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$settings = isset( $_POST['ta_notifications'] ) && is_array( $_POST['ta_notifications'] ) ? $_POST['ta_notifications'] : array();

		// Sanitize settings.
		$sanitized = array(
			'alert_emails'         => $this->security->sanitize_text( $settings['alert_emails'] ?? '' ),
			'on_worker_failure'    => isset( $settings['on_worker_failure'] ),
			'on_high_error_rate'   => isset( $settings['on_high_error_rate'] ),
			'on_cache_issues'      => isset( $settings['on_cache_issues'] ),
			'daily_digest'         => isset( $settings['daily_digest'] ),
			'error_rate_threshold' => absint( $settings['error_rate_threshold'] ?? 10 ),
		);

		$this->notifications->save_notification_settings( $sanitized );
		$this->logger->info( 'Notification settings updated.' );

		add_settings_error(
			'ta_messages',
			'ta_notifications_saved',
			__( 'Notification settings saved.', 'third-audience' ),
			'success'
		);

		$this->redirect_to_settings( 'notifications' );
	}

	/**
	 * AJAX handler for testing connection.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_test_connection() {
		$this->security->verify_ajax_request( 'admin_ajax' );

		$api_client = new TA_API_Client();
		$worker_url = $api_client->get_worker_url();

		// Validate URL.
		$validated_url = $this->security->validate_url_for_worker( $worker_url );
		if ( is_wp_error( $validated_url ) ) {
			wp_send_json_error( array( 'message' => $validated_url->get_error_message() ) );
		}

		$response = wp_remote_get( $worker_url . '/health', array( 'timeout' => 10 ) );

		if ( is_wp_error( $response ) ) {
			$this->logger->error( 'Worker connection test failed (AJAX).', array(
				'error' => $response->get_error_message(),
			) );
			wp_send_json_error( array( 'message' => $response->get_error_message() ) );
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( 200 === $status_code ) {
			$body = wp_remote_retrieve_body( $response );
			$data = json_decode( $body, true );
			wp_send_json_success( array(
				'message' => __( 'Connection successful!', 'third-audience' ),
				'data'    => $data,
			) );
		} else {
			wp_send_json_error( array(
				/* translators: %d: HTTP status code */
				'message' => sprintf( __( 'Worker returned status %d', 'third-audience' ), $status_code ),
			) );
		}
	}

	/**
	 * AJAX handler for testing SMTP.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_test_smtp() {
		$this->security->verify_ajax_request( 'admin_ajax' );

		$result = $this->notifications->test_smtp();

		if ( is_wp_error( $result ) ) {
			$this->logger->error( 'SMTP test failed (AJAX).', array(
				'error' => $result->get_error_message(),
			) );
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array(
			'message' => __( 'Test email sent successfully!', 'third-audience' ),
		) );
	}

	/**
	 * AJAX handler for clearing cache.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_clear_cache() {
		$this->security->verify_ajax_request( 'admin_ajax' );

		$cache_manager = new TA_Cache_Manager();
		$cleared       = $cache_manager->clear_all();

		$this->logger->info( 'Cache cleared (AJAX).', array( 'items' => $cleared ) );

		wp_send_json_success( array(
			/* translators: %d: Number of cached items cleared */
			'message' => sprintf( __( 'Cleared %d cached items.', 'third-audience' ), $cleared ),
			'count'   => $cleared,
		) );
	}

	/**
	 * AJAX handler for getting recent errors.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_get_recent_errors() {
		$this->security->verify_ajax_request( 'admin_ajax' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$limit  = isset( $_REQUEST['limit'] ) ? absint( $_REQUEST['limit'] ) : 20;
		$errors = $this->logger->get_recent_errors( $limit );

		wp_send_json_success( array(
			'errors' => $errors,
			'stats'  => $this->logger->get_stats(),
		) );
	}

	/**
	 * Redirect to settings page with optional tab.
	 *
	 * @since 1.1.0
	 * @param string $tab Optional tab to redirect to.
	 * @return void
	 */
	private function redirect_to_settings( $tab = '' ) {
		set_transient( 'settings_errors', get_settings_errors(), 30 );

		$args = array(
			'page'             => 'third-audience',
			'settings-updated' => 'true',
		);

		if ( ! empty( $tab ) ) {
			$args['tab'] = $tab;
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'options-general.php' ) ) );
		exit;
	}
}
