<?php
/**
 * Uninstall script
 *
 * @package ThirdAudience
 */

// Exit if uninstall not called from WordPress
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options
delete_option('ta_router_url');
delete_option('ta_worker_url');
delete_option('ta_api_key');
delete_option('ta_api_key_encrypted');
delete_option('ta_cache_ttl');
delete_option('ta_enabled_post_types');
delete_option('ta_enable_content_negotiation');
delete_option('ta_enable_discovery_tags');

// Clear all cached transients
global $wpdb;
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ta_md_%' OR option_name LIKE '_transient_timeout_ta_md_%'"
);

// Flush rewrite rules
flush_rewrite_rules();
