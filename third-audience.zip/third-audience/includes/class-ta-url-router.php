<?php
/**
 * URL Router - Handles .md URL requests
 *
 * @package ThirdAudience
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class TA_URL_Router
 */
class TA_URL_Router {

    /**
     * Cache Manager instance
     *
     * @var TA_Cache_Manager
     */
    private $cache_manager;

    /**
     * API Client instance
     *
     * @var TA_API_Client
     */
    private $api_client;

    /**
     * Constructor
     *
     * @param TA_Cache_Manager $cache_manager Cache manager instance.
     */
    public function __construct($cache_manager) {
        $this->cache_manager = $cache_manager;
        $this->api_client = new TA_API_Client();
    }

    /**
     * Register rewrite rules for .md URLs
     */
    public function register_rewrite_rules() {
        // Match any URL ending in .md
        add_rewrite_rule(
            '(.+)\.md$',
            'index.php?ta_markdown=1&ta_path=$matches[1]',
            'top'
        );

        // Register query vars
        add_rewrite_tag('%ta_markdown%', '1');
        add_rewrite_tag('%ta_path%', '([^&]+)');
    }

    /**
     * Handle incoming markdown requests
     */
    public function handle_markdown_request() {
        if (!get_query_var('ta_markdown')) {
            return;
        }

        $path = get_query_var('ta_path');
        if (empty($path)) {
            $this->send_error_response(400, 'Invalid path');
            return;
        }

        // Build the original URL (without .md)
        $original_url = home_url('/' . $path);

        // Check if this URL exists as a post/page
        $post_id = url_to_postid($original_url);
        if (!$post_id) {
            // Try with trailing slash
            $post_id = url_to_postid(trailingslashit($original_url));
        }

        if (!$post_id) {
            $this->send_error_response(404, 'Post not found');
            return;
        }

        // Check if post type is enabled
        $post = get_post($post_id);
        $enabled_types = get_option('ta_enabled_post_types', array('post', 'page'));
        if (!in_array($post->post_type, $enabled_types, true)) {
            $this->send_error_response(404, 'Post type not enabled');
            return;
        }

        // Check cache first
        $cache_key = $this->cache_manager->get_cache_key($original_url);
        $cached = $this->cache_manager->get($cache_key);

        if ($cached !== false) {
            $this->send_markdown_response($cached, true);
            return;
        }

        // Fetch from worker
        $markdown = $this->fetch_markdown($original_url);

        if ($markdown === false) {
            $this->send_error_response(502, 'Failed to convert content');
            return;
        }

        // Cache the result
        $this->cache_manager->set($cache_key, $markdown);

        $this->send_markdown_response($markdown, false);
    }

    /**
     * Fetch markdown from the worker
     *
     * @param string $url The URL to convert.
     * @return string|false The markdown content or false on failure.
     */
    private function fetch_markdown($url) {
        // Get worker from router (or use direct worker URL)
        $worker_url = $this->api_client->get_worker_url();
        if (!$worker_url) {
            error_log('Third Audience: Failed to get worker URL');
            return false;
        }

        // Call worker to convert
        $response = wp_remote_post(
            $worker_url . '/convert',
            array(
                'timeout' => 30,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Accept' => 'text/markdown',
                ),
                'body' => wp_json_encode(array(
                    'url' => $url,
                    'options' => array(
                        'include_frontmatter' => true,
                        'extract_main_content' => true,
                    ),
                )),
            )
        );

        if (is_wp_error($response)) {
            error_log('Third Audience: Worker request failed - ' . $response->get_error_message());
            return false;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            error_log('Third Audience: Worker returned status ' . $status_code);
            return false;
        }

        $body = wp_remote_retrieve_body($response);

        // Check if response is JSON (error) or markdown (success)
        $content_type = wp_remote_retrieve_header($response, 'content-type');
        if (strpos($content_type, 'application/json') !== false) {
            $data = json_decode($body, true);
            if (!empty($data['markdown'])) {
                return $data['markdown'];
            }
            error_log('Third Audience: Worker returned error - ' . ($data['error']['message'] ?? 'Unknown'));
            return false;
        }

        return $body;
    }

    /**
     * Send markdown response
     *
     * @param string $markdown The markdown content.
     * @param bool   $cache_hit Whether this was a cache hit.
     */
    private function send_markdown_response($markdown, $cache_hit) {
        status_header(200);
        header('Content-Type: text/markdown; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        header('X-Cache-Status: ' . ($cache_hit ? 'HIT' : 'MISS'));
        header('X-Powered-By: Third Audience');

        echo $markdown;
        exit;
    }

    /**
     * Send error response
     *
     * @param int    $status_code HTTP status code.
     * @param string $message Error message.
     */
    private function send_error_response($status_code, $message) {
        status_header($status_code);
        header('Content-Type: text/plain; charset=utf-8');

        echo 'Third Audience Error: ' . esc_html($message);
        exit;
    }
}
