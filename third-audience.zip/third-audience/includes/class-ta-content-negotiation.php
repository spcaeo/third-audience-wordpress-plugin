<?php
/**
 * Content Negotiation - Handles Accept: text/markdown requests
 *
 * @package ThirdAudience
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class TA_Content_Negotiation
 */
class TA_Content_Negotiation {

    /**
     * Handle content negotiation based on Accept header
     */
    public function handle_content_negotiation() {
        // Only on singular pages
        if (!is_singular()) {
            return;
        }

        // Check Accept header
        $accept = isset($_SERVER['HTTP_ACCEPT']) ? sanitize_text_field($_SERVER['HTTP_ACCEPT']) : '';

        if (strpos($accept, 'text/markdown') === false) {
            return;
        }

        // Check if post type is enabled
        $enabled_types = get_option('ta_enabled_post_types', array('post', 'page'));
        if (!in_array(get_post_type(), $enabled_types, true)) {
            return;
        }

        // Redirect to .md URL
        $current_url = get_permalink();
        $markdown_url = untrailingslashit($current_url) . '.md';

        // Use 303 See Other for content negotiation redirect
        wp_redirect($markdown_url, 303);
        exit;
    }
}
