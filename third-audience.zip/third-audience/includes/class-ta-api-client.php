<?php
/**
 * API Client - Communicates with Router/Worker services
 *
 * @package ThirdAudience
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class TA_API_Client
 */
class TA_API_Client {

    /**
     * Default worker URL (direct, bypassing router for simplicity)
     */
    const DEFAULT_WORKER_URL = 'https://ta-worker.rp-2ae.workers.dev';

    /**
     * Default router URL
     */
    const DEFAULT_ROUTER_URL = 'https://ta-router.rp-2ae.workers.dev';

    /**
     * Get the worker URL to use for conversion
     *
     * @return string|false The worker URL or false on failure.
     */
    public function get_worker_url() {
        // Check if router is configured
        $router_url = get_option('ta_router_url', self::DEFAULT_ROUTER_URL);
        $api_key = $this->get_api_key();

        // If we have a router URL and API key, use the router
        if (!empty($router_url) && !empty($api_key)) {
            $worker = $this->get_worker_from_router($router_url, $api_key);
            if ($worker) {
                return $worker['url'];
            }
        }

        // Fallback to direct worker URL
        $worker_url = get_option('ta_worker_url', self::DEFAULT_WORKER_URL);
        return !empty($worker_url) ? $worker_url : self::DEFAULT_WORKER_URL;
    }

    /**
     * Get a worker from the router service
     *
     * @param string $router_url Router service URL.
     * @param string $api_key API key.
     * @return array|false Worker info or false on failure.
     */
    private function get_worker_from_router($router_url, $api_key) {
        $response = wp_remote_get(
            $router_url . '/get-worker',
            array(
                'timeout' => 10,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'X-Site-URL' => home_url(),
                ),
            )
        );

        if (is_wp_error($response)) {
            error_log('Third Audience: Router request failed - ' . $response->get_error_message());
            return false;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            error_log('Third Audience: Router returned status ' . $status_code);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['success']) || empty($data['worker'])) {
            error_log('Third Audience: Router returned invalid response');
            return false;
        }

        return $data['worker'];
    }

    /**
     * Track usage with the router
     *
     * @param string $worker_id Worker ID.
     * @param string $url_converted URL that was converted.
     * @param int    $bytes_in Input bytes.
     * @param int    $bytes_out Output bytes.
     * @param int    $conversion_time_ms Conversion time in milliseconds.
     * @param bool   $cache_hit Whether it was a cache hit.
     * @param bool   $success Whether conversion succeeded.
     */
    public function track_usage($worker_id, $url_converted, $bytes_in, $bytes_out, $conversion_time_ms, $cache_hit, $success) {
        $router_url = get_option('ta_router_url', self::DEFAULT_ROUTER_URL);
        $api_key = $this->get_api_key();

        if (empty($router_url) || empty($api_key)) {
            return;
        }

        // Fire and forget - don't wait for response
        wp_remote_post(
            $router_url . '/track-usage',
            array(
                'timeout' => 1,
                'blocking' => false,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(array(
                    'worker_id' => $worker_id,
                    'site_url' => home_url(),
                    'url_converted' => $url_converted,
                    'bytes_in' => $bytes_in,
                    'bytes_out' => $bytes_out,
                    'conversion_time_ms' => $conversion_time_ms,
                    'cache_hit' => $cache_hit,
                    'success' => $success,
                )),
            )
        );
    }

    /**
     * Get the API key
     *
     * @return string The API key.
     */
    private function get_api_key() {
        $encrypted = get_option('ta_api_key_encrypted', '');
        if (empty($encrypted)) {
            return get_option('ta_api_key', '');
        }

        // Decrypt using WordPress auth key
        $decoded = base64_decode($encrypted);
        if (!$decoded) {
            return '';
        }

        $key = defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : AUTH_KEY;
        $key = str_repeat($key, ceil(strlen($decoded) / strlen($key)));

        return $decoded ^ substr($key, 0, strlen($decoded));
    }

    /**
     * Store the API key (encrypted)
     *
     * @param string $api_key The API key to store.
     */
    public function store_api_key($api_key) {
        if (empty($api_key)) {
            delete_option('ta_api_key_encrypted');
            delete_option('ta_api_key');
            return;
        }

        $key = defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : AUTH_KEY;
        $key = str_repeat($key, ceil(strlen($api_key) / strlen($key)));

        $encrypted = base64_encode($api_key ^ substr($key, 0, strlen($api_key)));
        update_option('ta_api_key_encrypted', $encrypted);
        delete_option('ta_api_key'); // Remove unencrypted version
    }
}
