<?php
/**
 * Cache Manager - Handles WordPress Transient caching
 *
 * @package ThirdAudience
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class TA_Cache_Manager
 */
class TA_Cache_Manager {

    /**
     * Cache key prefix
     */
    const CACHE_PREFIX = 'ta_md_';

    /**
     * Get cache key for a URL
     *
     * @param string $url The URL.
     * @return string The cache key.
     */
    public function get_cache_key($url) {
        return self::CACHE_PREFIX . md5($url);
    }

    /**
     * Get cached markdown
     *
     * @param string $cache_key The cache key.
     * @return string|false The cached content or false.
     */
    public function get($cache_key) {
        return get_transient($cache_key);
    }

    /**
     * Set cached markdown
     *
     * @param string $cache_key The cache key.
     * @param string $content The content to cache.
     * @return bool Success.
     */
    public function set($cache_key, $content) {
        $ttl = (int) get_option('ta_cache_ttl', 86400);
        return set_transient($cache_key, $content, $ttl);
    }

    /**
     * Delete cached markdown
     *
     * @param string $cache_key The cache key.
     * @return bool Success.
     */
    public function delete($cache_key) {
        return delete_transient($cache_key);
    }

    /**
     * Invalidate cache for a post
     *
     * @param int $post_id The post ID.
     */
    public function invalidate_post_cache($post_id) {
        $post = get_post($post_id);

        if (!$post || $post->post_status !== 'publish') {
            return;
        }

        // Get the post URL
        $url = get_permalink($post_id);
        if (!$url) {
            return;
        }

        // Delete the cache
        $cache_key = $this->get_cache_key($url);
        $this->delete($cache_key);

        // Also try with trailing slash variations
        $this->delete($this->get_cache_key(trailingslashit($url)));
        $this->delete($this->get_cache_key(untrailingslashit($url)));

        // Log invalidation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Third Audience: Invalidated cache for post ' . $post_id . ' - ' . $url);
        }
    }

    /**
     * Clear all Third Audience cache
     *
     * @return int Number of items cleared.
     */
    public function clear_all() {
        global $wpdb;

        // Delete all transients with our prefix
        $count = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%',
                '_transient_timeout_' . self::CACHE_PREFIX . '%'
            )
        );

        return $count / 2; // Each transient has two entries
    }

    /**
     * Get cache statistics
     *
     * @return array Cache statistics.
     */
    public function get_stats() {
        global $wpdb;

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%'
            )
        );

        $size = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%'
            )
        );

        return array(
            'count' => (int) $count,
            'size_bytes' => (int) $size,
            'size_human' => size_format((int) $size),
        );
    }
}
