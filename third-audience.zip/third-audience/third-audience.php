<?php
/**
 * Plugin Name: Third Audience
 * Plugin URI: https://third-audience.dev
 * Description: Serve AI-optimized Markdown versions of your content to AI crawlers (ClaudeBot, GPTBot, PerplexityBot)
 * Version: 1.0.0
 * Author: Third Audience
 * Author URI: https://third-audience.dev
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: third-audience
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('TA_VERSION', '1.0.0');
define('TA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TA_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
require_once TA_PLUGIN_DIR . 'includes/class-third-audience.php';
require_once TA_PLUGIN_DIR . 'includes/class-ta-url-router.php';
require_once TA_PLUGIN_DIR . 'includes/class-ta-content-negotiation.php';
require_once TA_PLUGIN_DIR . 'includes/class-ta-discovery.php';
require_once TA_PLUGIN_DIR . 'includes/class-ta-cache-manager.php';
require_once TA_PLUGIN_DIR . 'includes/class-ta-api-client.php';

// Admin includes
if (is_admin()) {
    require_once TA_PLUGIN_DIR . 'admin/class-ta-admin.php';
}

/**
 * Initialize the plugin
 */
function ta_init() {
    $plugin = new Third_Audience();
    $plugin->init();
}
add_action('plugins_loaded', 'ta_init');

/**
 * Activation hook
 */
function ta_activate() {
    // Flush rewrite rules on activation
    flush_rewrite_rules();

    // Set default options
    if (!get_option('ta_cache_ttl')) {
        update_option('ta_cache_ttl', 86400);
    }
    if (!get_option('ta_enabled_post_types')) {
        update_option('ta_enabled_post_types', array('post', 'page'));
    }
    if (!get_option('ta_enable_content_negotiation')) {
        update_option('ta_enable_content_negotiation', true);
    }
    if (!get_option('ta_enable_discovery_tags')) {
        update_option('ta_enable_discovery_tags', true);
    }
}
register_activation_hook(__FILE__, 'ta_activate');

/**
 * Deactivation hook
 */
function ta_deactivate() {
    // Flush rewrite rules on deactivation
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'ta_deactivate');
