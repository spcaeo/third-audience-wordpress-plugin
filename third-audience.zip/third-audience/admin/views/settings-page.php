<?php
/**
 * Settings page template
 *
 * @package ThirdAudience
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <div class="ta-admin-container" style="display: flex; gap: 20px; flex-wrap: wrap;">
        <div class="ta-settings-main" style="flex: 2; min-width: 400px;">
            <form method="post" action="options.php">
                <?php settings_fields('ta_settings'); ?>

                <h2><?php _e('Service Configuration', 'third-audience'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ta_worker_url"><?php _e('Worker URL', 'third-audience'); ?></label>
                        </th>
                        <td>
                            <input type="url" name="ta_worker_url" id="ta_worker_url" class="regular-text"
                                value="<?php echo esc_attr(get_option('ta_worker_url', 'https://ta-worker.rp-2ae.workers.dev')); ?>" />
                            <p class="description"><?php _e('Cloudflare Worker URL for HTML-to-Markdown conversion.', 'third-audience'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ta_router_url"><?php _e('Router URL (Optional)', 'third-audience'); ?></label>
                        </th>
                        <td>
                            <input type="url" name="ta_router_url" id="ta_router_url" class="regular-text"
                                value="<?php echo esc_attr(get_option('ta_router_url', '')); ?>" />
                            <p class="description"><?php _e('Router service URL for load balancing (leave empty to use Worker directly).', 'third-audience'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ta_api_key"><?php _e('API Key (Optional)', 'third-audience'); ?></label>
                        </th>
                        <td>
                            <input type="password" name="ta_api_key" id="ta_api_key" class="regular-text"
                                value="" placeholder="<?php echo get_option('ta_api_key_encrypted') ? '********' : ''; ?>" />
                            <p class="description"><?php _e('API key for router authentication (required if using router).', 'third-audience'); ?></p>
                        </td>
                    </tr>
                </table>

                <h2><?php _e('Cache Settings', 'third-audience'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ta_cache_ttl"><?php _e('Cache Duration', 'third-audience'); ?></label>
                        </th>
                        <td>
                            <select name="ta_cache_ttl" id="ta_cache_ttl">
                                <option value="3600" <?php selected(get_option('ta_cache_ttl', 86400), 3600); ?>><?php _e('1 Hour', 'third-audience'); ?></option>
                                <option value="21600" <?php selected(get_option('ta_cache_ttl', 86400), 21600); ?>><?php _e('6 Hours', 'third-audience'); ?></option>
                                <option value="43200" <?php selected(get_option('ta_cache_ttl', 86400), 43200); ?>><?php _e('12 Hours', 'third-audience'); ?></option>
                                <option value="86400" <?php selected(get_option('ta_cache_ttl', 86400), 86400); ?>><?php _e('24 Hours', 'third-audience'); ?></option>
                                <option value="604800" <?php selected(get_option('ta_cache_ttl', 86400), 604800); ?>><?php _e('7 Days', 'third-audience'); ?></option>
                            </select>
                            <p class="description"><?php _e('How long to cache converted markdown.', 'third-audience'); ?></p>
                        </td>
                    </tr>
                </table>

                <h2><?php _e('Feature Settings', 'third-audience'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Enabled Post Types', 'third-audience'); ?></th>
                        <td>
                            <?php
                            $enabled_types = get_option('ta_enabled_post_types', array('post', 'page'));
                            $post_types = get_post_types(array('public' => true), 'objects');
                            foreach ($post_types as $post_type) :
                                if ($post_type->name === 'attachment') continue;
                            ?>
                                <label style="display: block; margin-bottom: 5px;">
                                    <input type="checkbox" name="ta_enabled_post_types[]"
                                        value="<?php echo esc_attr($post_type->name); ?>"
                                        <?php checked(in_array($post_type->name, $enabled_types)); ?> />
                                    <?php echo esc_html($post_type->labels->name); ?>
                                </label>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Content Negotiation', 'third-audience'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="ta_enable_content_negotiation" value="1"
                                    <?php checked(get_option('ta_enable_content_negotiation', true)); ?> />
                                <?php _e('Enable Accept: text/markdown header support', 'third-audience'); ?>
                            </label>
                            <p class="description"><?php _e('Redirect to .md URL when client sends Accept: text/markdown header.', 'third-audience'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Discovery Tags', 'third-audience'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="ta_enable_discovery_tags" value="1"
                                    <?php checked(get_option('ta_enable_discovery_tags', true)); ?> />
                                <?php _e('Add &lt;link rel="alternate"&gt; tags', 'third-audience'); ?>
                            </label>
                            <p class="description"><?php _e('Help AI crawlers discover markdown versions of your content.', 'third-audience'); ?></p>
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>

        <div class="ta-settings-sidebar" style="flex: 1; min-width: 300px;">
            <div class="card" style="padding: 15px;">
                <h2><?php _e('Cache Status', 'third-audience'); ?></h2>
                <p>
                    <strong><?php _e('Cached Items:', 'third-audience'); ?></strong>
                    <?php echo esc_html($cache_stats['count']); ?>
                </p>
                <p>
                    <strong><?php _e('Cache Size:', 'third-audience'); ?></strong>
                    <?php echo esc_html($cache_stats['size_human']); ?>
                </p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('ta_clear_cache'); ?>
                    <input type="hidden" name="action" value="ta_clear_cache" />
                    <?php submit_button(__('Clear All Cache', 'third-audience'), 'secondary', 'submit', false); ?>
                </form>
            </div>

            <div class="card" style="padding: 15px; margin-top: 20px;">
                <h2><?php _e('Connection Test', 'third-audience'); ?></h2>
                <p><?php _e('Test the connection to the conversion service.', 'third-audience'); ?></p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('ta_test_connection'); ?>
                    <input type="hidden" name="action" value="ta_test_connection" />
                    <?php submit_button(__('Test Connection', 'third-audience'), 'secondary', 'submit', false); ?>
                </form>
            </div>

            <div class="card" style="padding: 15px; margin-top: 20px;">
                <h2><?php _e('How It Works', 'third-audience'); ?></h2>
                <ol style="padding-left: 20px;">
                    <li><?php _e('AI crawlers request <code>page.md</code> URLs', 'third-audience'); ?></li>
                    <li><?php _e('Plugin intercepts the request', 'third-audience'); ?></li>
                    <li><?php _e('Checks local cache first', 'third-audience'); ?></li>
                    <li><?php _e('If miss, converts HTML to Markdown', 'third-audience'); ?></li>
                    <li><?php _e('Caches and returns clean Markdown', 'third-audience'); ?></li>
                </ol>
            </div>

            <div class="card" style="padding: 15px; margin-top: 20px;">
                <h2><?php _e('Test Your Setup', 'third-audience'); ?></h2>
                <p><?php _e('Try requesting a markdown version:', 'third-audience'); ?></p>
                <?php
                $sample_post = get_posts(array('numberposts' => 1, 'post_status' => 'publish'));
                if ($sample_post) :
                    $md_url = untrailingslashit(get_permalink($sample_post[0])) . '.md';
                ?>
                    <p>
                        <a href="<?php echo esc_url($md_url); ?>" target="_blank" class="button">
                            <?php _e('View Sample .md', 'third-audience'); ?>
                        </a>
                    </p>
                    <p class="description">
                        <code style="word-break: break-all;"><?php echo esc_html($md_url); ?></code>
                    </p>
                <?php else : ?>
                    <p class="description"><?php _e('No published posts found.', 'third-audience'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
