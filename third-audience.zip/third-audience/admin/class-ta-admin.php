<?php
/**
 * Admin - Settings page and admin functionality
 *
 * @package ThirdAudience
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class TA_Admin
 */
class TA_Admin {

    /**
     * Initialize admin functionality
     */
    public function init() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_ta_clear_cache', array($this, 'handle_clear_cache'));
        add_action('admin_post_ta_test_connection', array($this, 'handle_test_connection'));
    }

    /**
     * Add settings page to admin menu
     */
    public function add_settings_page() {
        add_options_page(
            __('Third Audience Settings', 'third-audience'),
            __('Third Audience', 'third-audience'),
            'manage_options',
            'third-audience',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        // Service settings
        register_setting('ta_settings', 'ta_router_url', array(
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => 'https://ta-router.rp-2ae.workers.dev',
        ));

        register_setting('ta_settings', 'ta_worker_url', array(
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => 'https://ta-worker.rp-2ae.workers.dev',
        ));

        register_setting('ta_settings', 'ta_api_key', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_api_key'),
        ));

        // Cache settings
        register_setting('ta_settings', 'ta_cache_ttl', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 86400,
        ));

        // Feature settings
        register_setting('ta_settings', 'ta_enabled_post_types', array(
            'type' => 'array',
            'sanitize_callback' => array($this, 'sanitize_post_types'),
            'default' => array('post', 'page'),
        ));

        register_setting('ta_settings', 'ta_enable_content_negotiation', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true,
        ));

        register_setting('ta_settings', 'ta_enable_discovery_tags', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true,
        ));
    }

    /**
     * Sanitize API key (encrypt and store)
     *
     * @param string $value The API key.
     * @return string Empty string (we store encrypted separately).
     */
    public function sanitize_api_key($value) {
        if (!empty($value)) {
            $api_client = new TA_API_Client();
            $api_client->store_api_key(sanitize_text_field($value));
        }
        return ''; // Don't store unencrypted
    }

    /**
     * Sanitize post types
     *
     * @param mixed $value The value.
     * @return array Sanitized post types.
     */
    public function sanitize_post_types($value) {
        if (!is_array($value)) {
            return array('post', 'page');
        }
        return array_map('sanitize_key', $value);
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Show admin notices
        settings_errors('ta_messages');

        $cache_manager = new TA_Cache_Manager();
        $cache_stats = $cache_manager->get_stats();

        include TA_PLUGIN_DIR . 'admin/views/settings-page.php';
    }

    /**
     * Handle clear cache action
     */
    public function handle_clear_cache() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'third-audience'));
        }

        check_admin_referer('ta_clear_cache');

        $cache_manager = new TA_Cache_Manager();
        $cleared = $cache_manager->clear_all();

        add_settings_error(
            'ta_messages',
            'ta_cache_cleared',
            sprintf(__('Cleared %d cached items.', 'third-audience'), $cleared),
            'success'
        );

        wp_redirect(add_query_arg('settings-updated', 'true', admin_url('options-general.php?page=third-audience')));
        exit;
    }

    /**
     * Handle test connection action
     */
    public function handle_test_connection() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'third-audience'));
        }

        check_admin_referer('ta_test_connection');

        $api_client = new TA_API_Client();
        $worker_url = $api_client->get_worker_url();

        // Test worker health
        $response = wp_remote_get($worker_url . '/health', array('timeout' => 10));

        if (is_wp_error($response)) {
            add_settings_error(
                'ta_messages',
                'ta_test_failed',
                __('Connection failed: ', 'third-audience') . $response->get_error_message(),
                'error'
            );
        } else {
            $status_code = wp_remote_retrieve_response_code($response);
            if ($status_code === 200) {
                add_settings_error(
                    'ta_messages',
                    'ta_test_success',
                    __('Connection successful! Worker is healthy.', 'third-audience'),
                    'success'
                );
            } else {
                add_settings_error(
                    'ta_messages',
                    'ta_test_failed',
                    sprintf(__('Worker returned status %d', 'third-audience'), $status_code),
                    'error'
                );
            }
        }

        wp_redirect(add_query_arg('settings-updated', 'true', admin_url('options-general.php?page=third-audience')));
        exit;
    }
}
